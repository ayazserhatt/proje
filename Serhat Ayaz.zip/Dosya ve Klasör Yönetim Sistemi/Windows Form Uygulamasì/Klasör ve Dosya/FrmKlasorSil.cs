﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class FrmKlasorSil : Form
    {
        public FrmKlasorSil()
        {
            InitializeComponent();
            Listele();
        }

        private void Listele()
        {
            string hedefDizin = @"C:\\";

            if (Directory.Exists(hedefDizin))
            {
                dgvKlasorler.Rows.Clear();
                dgvKlasorler.Columns.Clear();

                dgvKlasorler.Columns.Add("Ad", "Ad");
                dgvKlasorler.Columns.Add("Yol", "Tam Yol");

                string[] klasorler = Directory.GetDirectories(hedefDizin);
                foreach (var klasor in klasorler)
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(klasor);
                    dgvKlasorler.Rows.Add(dirInfo.Name, dirInfo.FullName);
                }
            }
        }
        private void FrmKlasorSil_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnKlasorSil_Click(object sender, EventArgs e)
        {
            if (dgvKlasorler.SelectedRows.Count > 0)
            {
                string tamYol = dgvKlasorler.SelectedRows[0].Cells["Yol"].Value.ToString();

                if (Directory.Exists(tamYol))
                {
                    Directory.Delete(tamYol, true);
                    MessageBox.Show("Klasör başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Listele();
                }
                else
                {
                    MessageBox.Show("Klasör bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Silmek için bir klasör seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
