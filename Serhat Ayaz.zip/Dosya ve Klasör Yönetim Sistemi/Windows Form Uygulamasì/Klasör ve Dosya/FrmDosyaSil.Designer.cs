﻿namespace Klasör_ve_Dosya
{
    partial class FrmDosyaSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDosyalar = new System.Windows.Forms.DataGridView();
            this.btnDosyaSil = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDosyalar)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDosyalar
            // 
            this.dgvDosyalar.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvDosyalar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDosyalar.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDosyalar.Location = new System.Drawing.Point(39, 31);
            this.dgvDosyalar.Name = "dgvDosyalar";
            this.dgvDosyalar.RowHeadersWidth = 51;
            this.dgvDosyalar.RowTemplate.Height = 24;
            this.dgvDosyalar.Size = new System.Drawing.Size(482, 288);
            this.dgvDosyalar.TabIndex = 0;
            // 
            // btnDosyaSil
            // 
            this.btnDosyaSil.Location = new System.Drawing.Point(386, 325);
            this.btnDosyaSil.Name = "btnDosyaSil";
            this.btnDosyaSil.Size = new System.Drawing.Size(102, 33);
            this.btnDosyaSil.TabIndex = 1;
            this.btnDosyaSil.Text = "Sil";
            this.btnDosyaSil.UseVisualStyleBackColor = true;
            this.btnDosyaSil.Click += new System.EventHandler(this.btnDosyaSil_Click);
            // 
            // FrmDosyaSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 370);
            this.Controls.Add(this.btnDosyaSil);
            this.Controls.Add(this.dgvDosyalar);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmDosyaSil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dosya Sil";
            this.Load += new System.EventHandler(this.FrmDosyaSil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDosyalar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDosyalar;
        private System.Windows.Forms.Button btnDosyaSil;
    }
}