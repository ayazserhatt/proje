﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class FrmDosyaDetay : Form
    {
        public FrmDosyaDetay()
        {
            InitializeComponent();
            Listele();
        }
        private void Listele()
        {
            string hedefDizin = @"C:\\"; 

            if (Directory.Exists(hedefDizin))
            {
                dgvDosyaDetay.Rows.Clear();
                dgvDosyaDetay.Columns.Clear();

                dgvDosyaDetay.Columns.Add("Ad", "Ad");
                dgvDosyaDetay.Columns.Add("Yol", "Tam Yol");

                string[] dosyalar = Directory.GetFiles(hedefDizin);
                foreach (var dosya in dosyalar)
                {
                    FileInfo fileInfo = new FileInfo(dosya);
                    dgvDosyaDetay.Rows.Add(fileInfo.Name, fileInfo.FullName);
                }
            }
        }
        private void FrmDosyaDetay_Load(object sender, EventArgs e)
        {

        }

        private void dgvDosyaDetay_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string tamYol = dgvDosyaDetay.Rows[e.RowIndex].Cells["Yol"].Value.ToString();

                try
                {
                    // Dosyanın içeriğini oku
                    string icerik = File.ReadAllText(tamYol);
                    txtDosyaIcerik.Text = icerik;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Dosya içeriği okunurken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvDosyaDetay_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvDosyaDetay_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string tamYol = dgvDosyaDetay.Rows[e.RowIndex].Cells["Yol"].Value.ToString();

                try
                {
                    // Dosyanın içeriğini oku
                    string icerik = File.ReadAllText(tamYol);
                    txtDosyaIcerik.Text = icerik;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Dosya içeriği okunurken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
    }

}



        
