﻿namespace Klasör_ve_Dosya
{
    partial class FrmKlasorSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvKlasorler = new System.Windows.Forms.DataGridView();
            this.btnKlasorSil = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKlasorler)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvKlasorler
            // 
            this.dgvKlasorler.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvKlasorler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKlasorler.Location = new System.Drawing.Point(40, 27);
            this.dgvKlasorler.Name = "dgvKlasorler";
            this.dgvKlasorler.RowHeadersWidth = 51;
            this.dgvKlasorler.RowTemplate.Height = 24;
            this.dgvKlasorler.Size = new System.Drawing.Size(465, 283);
            this.dgvKlasorler.TabIndex = 0;
            this.dgvKlasorler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnKlasorSil
            // 
            this.btnKlasorSil.Location = new System.Drawing.Point(371, 316);
            this.btnKlasorSil.Name = "btnKlasorSil";
            this.btnKlasorSil.Size = new System.Drawing.Size(107, 33);
            this.btnKlasorSil.TabIndex = 1;
            this.btnKlasorSil.Text = "Sil";
            this.btnKlasorSil.UseVisualStyleBackColor = true;
            this.btnKlasorSil.Click += new System.EventHandler(this.btnKlasorSil_Click);
            // 
            // FrmKlasorSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 363);
            this.Controls.Add(this.btnKlasorSil);
            this.Controls.Add(this.dgvKlasorler);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmKlasorSil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Klasör Sil";
            this.Load += new System.EventHandler(this.FrmKlasorSil_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKlasorler)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvKlasorler;
        private System.Windows.Forms.Button btnKlasorSil;
    }
}