﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmListele listeleForm = new FrmListele();
            listeleForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmDosyaSil silForm = new FrmDosyaSil();
            silForm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmKlasorSil silKlasorForm = new FrmKlasorSil();
            silKlasorForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmDosyaDetay dosyaDetay = new FrmDosyaDetay();
            dosyaDetay.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmKlasorOlustur klasorOlustur = new FrmKlasorOlustur();
            klasorOlustur.ShowDialog();
        }
    }
}
