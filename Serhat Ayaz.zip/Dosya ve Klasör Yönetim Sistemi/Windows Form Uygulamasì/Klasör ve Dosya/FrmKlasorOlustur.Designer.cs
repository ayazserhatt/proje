﻿namespace Klasör_ve_Dosya
{
    partial class FrmKlasorOlustur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnKlasorOlustur = new System.Windows.Forms.Button();
            this.txtYeniKlasor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnKlasorOlustur
            // 
            this.btnKlasorOlustur.Location = new System.Drawing.Point(64, 132);
            this.btnKlasorOlustur.Name = "btnKlasorOlustur";
            this.btnKlasorOlustur.Size = new System.Drawing.Size(140, 31);
            this.btnKlasorOlustur.TabIndex = 0;
            this.btnKlasorOlustur.Text = "Oluştur";
            this.btnKlasorOlustur.UseVisualStyleBackColor = true;
            this.btnKlasorOlustur.Click += new System.EventHandler(this.btnKlasorOlustur_Click);
            // 
            // txtYeniKlasor
            // 
            this.txtYeniKlasor.Location = new System.Drawing.Point(41, 81);
            this.txtYeniKlasor.Name = "txtYeniKlasor";
            this.txtYeniKlasor.Size = new System.Drawing.Size(194, 27);
            this.txtYeniKlasor.TabIndex = 1;
            // 
            // FrmKlasorOlustur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 250);
            this.Controls.Add(this.txtYeniKlasor);
            this.Controls.Add(this.btnKlasorOlustur);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmKlasorOlustur";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Klasör Oluştur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnKlasorOlustur;
        private System.Windows.Forms.TextBox txtYeniKlasor;
    }
}