﻿namespace Klasör_ve_Dosya
{
    partial class FrmDosyaDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDosyaDetay = new System.Windows.Forms.DataGridView();
            this.txtDosyaIcerik = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDosyaDetay)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDosyaDetay
            // 
            this.dgvDosyaDetay.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDosyaDetay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDosyaDetay.Location = new System.Drawing.Point(39, 81);
            this.dgvDosyaDetay.Name = "dgvDosyaDetay";
            this.dgvDosyaDetay.RowHeadersWidth = 51;
            this.dgvDosyaDetay.RowTemplate.Height = 24;
            this.dgvDosyaDetay.Size = new System.Drawing.Size(533, 432);
            this.dgvDosyaDetay.TabIndex = 0;
            this.dgvDosyaDetay.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDosyaDetay_CellContentDoubleClick);
            this.dgvDosyaDetay.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDosyaDetay_CellDoubleClick);
            // 
            // txtDosyaIcerik
            // 
            this.txtDosyaIcerik.Location = new System.Drawing.Point(52, 37);
            this.txtDosyaIcerik.Multiline = true;
            this.txtDosyaIcerik.Name = "txtDosyaIcerik";
            this.txtDosyaIcerik.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDosyaIcerik.Size = new System.Drawing.Size(508, 24);
            this.txtDosyaIcerik.TabIndex = 1;
            // 
            // FrmDosyaDetay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 540);
            this.Controls.Add(this.txtDosyaIcerik);
            this.Controls.Add(this.dgvDosyaDetay);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmDosyaDetay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dosya Detayları";
            this.Load += new System.EventHandler(this.FrmDosyaDetay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDosyaDetay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDosyaDetay;
        private System.Windows.Forms.TextBox txtDosyaIcerik;
    }
}