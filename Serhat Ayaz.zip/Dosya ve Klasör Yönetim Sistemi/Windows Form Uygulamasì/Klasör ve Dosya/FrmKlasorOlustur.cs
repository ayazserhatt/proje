﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class FrmKlasorOlustur : Form
    {
        public FrmKlasorOlustur()
        {
            InitializeComponent();
        }

        private void btnKlasorOlustur_Click(object sender, EventArgs e)
        {
            {
                string yeniKlasor = txtYeniKlasor.Text;

                if (!Directory.Exists(yeniKlasor))
                {
                    Directory.CreateDirectory(yeniKlasor);
                    MessageBox.Show("Klasör başarıyla oluşturuldu.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Bu klasör zaten mevcut.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
