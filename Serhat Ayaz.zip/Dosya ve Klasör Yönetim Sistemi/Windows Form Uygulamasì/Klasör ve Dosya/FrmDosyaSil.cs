﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class FrmDosyaSil : Form
    {
        public FrmDosyaSil()
        {
            InitializeComponent();
            Listele();
        }

        private void Listele()
        {
            string hedefDizin = @"C:\\"; // Varsayılan dizin (kendi dizininizi belirleyin)

            if (Directory.Exists(hedefDizin))
            {
                dgvDosyalar.Rows.Clear();
                dgvDosyalar.Columns.Clear();

                dgvDosyalar.Columns.Add("Ad", "Ad");
                dgvDosyalar.Columns.Add("Yol", "Tam Yol");

                string[] dosyalar = Directory.GetFiles(hedefDizin);
                foreach (var dosya in dosyalar)
                {
                    FileInfo fileInfo = new FileInfo(dosya);
                    dgvDosyalar.Rows.Add(fileInfo.Name, fileInfo.FullName);
                }
            }
        }
        private void FrmDosyaSil_Load(object sender, EventArgs e)
        {

        }

        private void btnDosyaSil_Click(object sender, EventArgs e)
        {
            if (dgvDosyalar.SelectedRows.Count > 0)
            {
                string tamYol = dgvDosyalar.SelectedRows[0].Cells["Yol"].Value.ToString();

                if (File.Exists(tamYol))
                {
                    File.Delete(tamYol);
                    MessageBox.Show("Dosya başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Listele();
                }
                else
                {
                    MessageBox.Show("Dosya bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Silmek için bir dosya seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
