﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasör_ve_Dosya
{
    public partial class FrmListele : Form
    {
        public FrmListele()
        {
            InitializeComponent();
        }

        private void FrmListele_Load(object sender, EventArgs e)
        {

        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            {
                string hedefDizin = txtDizin.Text;

                if (Directory.Exists(hedefDizin))
                {
                    dgvListe.Rows.Clear();
                    dgvListe.Columns.Clear();

                    dgvListe.Columns.Add("Ad", "Ad");
                    dgvListe.Columns.Add("Tip", "Tip");
                    dgvListe.Columns.Add("Boyut", "Boyut (Bytes)");
                    dgvListe.Columns.Add("OlusturmaTarihi", "Oluşturma Tarihi");

                    // Dosyaları listele
                    string[] dosyalar = Directory.GetFiles(hedefDizin);
                    foreach (var dosya in dosyalar)
                    {
                        FileInfo fileInfo = new FileInfo(dosya);
                        dgvListe.Rows.Add(fileInfo.Name, "Dosya", fileInfo.Length, fileInfo.CreationTime);
                    }

                    // Klasörleri listele
                    string[] klasorler = Directory.GetDirectories(hedefDizin);
                    foreach (var klasor in klasorler)
                    {
                        DirectoryInfo dirInfo = new DirectoryInfo(klasor);
                        dgvListe.Rows.Add(dirInfo.Name, "Klasör", "-", dirInfo.CreationTime);
                    }
                }
                else
                {
                    MessageBox.Show("Geçerli bir dizin giriniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
