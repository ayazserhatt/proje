﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static List<string> dosyalar = new List<string>();
    static List<string> klasorler = new List<string>();
    static string logDosyasi = "islem_log.txt";

    static void Main(string[] args)
    {
        string anaDizin = "C:\\ProjeDizin";
        Directory.CreateDirectory(anaDizin);
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Dosya ve Klasör Yönetim Sistemi\n");

        int secim;
        do
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("1. Dosya ve klasörleri listele");
            Console.WriteLine("2. Dosya sil");
            Console.WriteLine("3. Klasör sil");
            Console.WriteLine("4. Dosya detaylarını görüntüle");
            Console.WriteLine("5. Yeni klasör oluştur");
            Console.WriteLine("6. Arama yap");
            Console.WriteLine("7. Çıkış\n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Seçiminizi yapın: ");
            secim = int.Parse(Console.ReadLine());

            switch (secim)
            {
                case 1:
                    Listele(anaDizin);
                    break;
                case 2:
                    SilDosya(anaDizin);
                    break;
                case 3:
                    SilKlasor(anaDizin);
                    break;
                case 4:
                    DetayGoster(anaDizin);
                    break;
                case 5:
                    YeniKlasor(anaDizin);
                    break;
                case 6:
                    AramaYap(anaDizin);
                    break;
                case 7:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Çıkış yapılıyor...");
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Geçersiz seçim!\n", ConsoleColor.Red);
                    break;
            }
        } while (secim != 7);
    }

    static void Listele(string anaDizin)
    {
        dosyalar.Clear();
        klasorler.Clear();

        dosyalar.AddRange(Directory.GetFiles(anaDizin));
        klasorler.AddRange(Directory.GetDirectories(anaDizin));

        Console.WriteLine("\nDosyalar:");
        foreach (var dosya in dosyalar.OrderBy(d => new FileInfo(d).Length))
        {
            Console.WriteLine(Path.GetFileName(dosya));
        }

        Console.WriteLine("\nKlasörler:");
        foreach (var klasor in klasorler)
        {
            Console.WriteLine(Path.GetFileName(klasor));
        }
        Console.WriteLine();

        LogKaydet("Dosya ve klasörler listelendi.");
    }

    static void SilDosya(string anaDizin)

    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Silmek istediğiniz dosyanın adını girin: ");
        string dosyaAdi = Console.ReadLine();
        string dosyaYolu = Path.Combine(anaDizin, dosyaAdi);

        if (File.Exists(dosyaYolu))
        {
            File.Delete(dosyaYolu);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Dosya silindi.\n");
            LogKaydet($"Dosya silindi: {dosyaAdi}");
        }
        else
        {
            Console.WriteLine("Dosya bulunamadı!\n");
        }
    }

    static void SilKlasor(string anaDizin)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("Silmek istediğiniz klasörün adını girin: ");
        string klasorAdi = Console.ReadLine();
        string klasorYolu = Path.Combine(anaDizin, klasorAdi);

        if (Directory.Exists(klasorYolu))
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Directory.Delete(klasorYolu, true);
            Console.WriteLine("Klasör ve içindekiler silindi.\n");
            LogKaydet($"Klasör silindi: {klasorAdi}");
        }
        else
        {
            Console.WriteLine("Klasör bulunamadı!\n");
        }
    }

    static void DetayGoster(string anaDizin)
    {
        Console.Write("Detaylarını görmek istediğiniz dosyanın adını girin: ");
        string dosyaAdi = Console.ReadLine();
        string dosyaYolu = Path.Combine(anaDizin, dosyaAdi);

        if (File.Exists(dosyaYolu))
        {
            FileInfo bilgi = new FileInfo(dosyaYolu);
            Console.WriteLine($"\nDosya Adı: {bilgi.Name}");
            Console.WriteLine($"Boyut: {bilgi.Length} bayt");
            Console.WriteLine($"Oluşturulma Tarihi: {bilgi.CreationTime}\n");
            LogKaydet($"Dosya detayları görüntülendi: {dosyaAdi}");
        }
        else
        {
            Console.WriteLine("Dosya bulunamadı!\n");
        }
    }

    static void YeniKlasor(string anaDizin)
    {
        Console.Write("Oluşturmak istediğiniz klasörün adını girin: ");
        string klasorAdi = Console.ReadLine();
        string klasorYolu = Path.Combine(anaDizin, klasorAdi);

        if (!Directory.Exists(klasorYolu))
        {
            Directory.CreateDirectory(klasorYolu);
            Console.WriteLine("Klasör oluşturuldu.\n");
            LogKaydet($"Yeni klasör oluşturuldu: {klasorAdi}");
        }
        else
        {
            Console.WriteLine("Bu adla zaten bir klasör var!\n");
        }
    }

    static void AramaYap(string anaDizin)
    {
        Console.Write("Aramak istediğiniz anahtar kelimeyi girin: ");
        string anahtarKelime = Console.ReadLine();

        Console.WriteLine("\nEşleşen Dosyalar:");
        var eslesenDosyalar = dosyalar.Where(d => Path.GetFileName(d).Contains(anahtarKelime));
        foreach (var dosya in eslesenDosyalar)
        {
            Console.WriteLine(Path.GetFileName(dosya));
        }

        Console.WriteLine("\nEşleşen Klasörler:");
        var eslesenKlasorler = klasorler.Where(k => Path.GetFileName(k).Contains(anahtarKelime));
        foreach (var klasor in eslesenKlasorler)
        {
            Console.WriteLine(Path.GetFileName(klasor));
        }
        Console.WriteLine();

        LogKaydet($"Arama yapıldı: {anahtarKelime}");
    }

    static void LogKaydet(string mesaj)
    {
        File.AppendAllText(logDosyasi, $"{DateTime.Now}: {mesaj}\n");
    }
}
