﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Projee
{
    public partial class KitapAlfrm1 : Form
    {
        public KitapAlfrm1()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=BLACK\\SQLEXPRESS;Initial Catalog=KütüphaneYönetimSistemi;Integrated Security=True;Encrypt=False");
        DataSet daset = new DataSet();

        private void btnİptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void sepetlistele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("SELECT * FROM sepet", baglanti);
            adtr.Fill(daset, "sepet");
            dataGridView1.DataSource = daset.Tables["sepet"];
            baglanti.Close();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtIsbn.Text) || string.IsNullOrEmpty(txtKitapAdi.Text) ||
                    string.IsNullOrEmpty(txtYazari.Text) || string.IsNullOrEmpty(txtKitapSayisi.Text) ||
                    !int.TryParse(txtKitapSayisi.Text, out int kitapSayisi))
                {
                    MessageBox.Show("Lütfen tüm alanları doğru bir şekilde doldurun.");
                    return;
                }

                string teslimTarihi = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                string iadeTarihi = dateTimePicker2.Value.ToString("yyyy-MM-dd");

                baglanti.Open();
                SqlCommand komut = new SqlCommand("INSERT INTO sepet (isbn, kitapadi, yazari, kitapsayisi, teslimtarihi, iadetarihi) VALUES (@isbn, @kitapadi, @yazari, @kitapsayisi, @teslimtarihi, @iadetarihi)", baglanti);
                komut.Parameters.AddWithValue("@isbn", txtIsbn.Text);
                komut.Parameters.AddWithValue("@kitapadi", txtKitapAdi.Text);
                komut.Parameters.AddWithValue("@yazari", txtYazari.Text);
                komut.Parameters.AddWithValue("@kitapsayisi", kitapSayisi);
                komut.Parameters.AddWithValue("@teslimtarihi", teslimTarihi);
                komut.Parameters.AddWithValue("@iadetarihi", iadeTarihi);
                komut.ExecuteNonQuery();
                baglanti.Close();

                MessageBox.Show("Kitap sepete eklendi.");

                daset.Tables["sepet"].Clear();
                sepetlistele();

                lblKitapSayisi.Text = "";
                kitapsayisi();

                foreach (Control item in grpKitapBilgi.Controls)
                {
                    if (item is TextBox textBox && item != txtKitapSayisi)
                    {
                        textBox.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
        }

        private void kitapsayisi()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("SELECT SUM(kitapsayisi) FROM sepet", baglanti);
            lblKitapSayisi.Text = komut.ExecuteScalar()?.ToString() ?? "0";
            baglanti.Close();
        }

        private void KitapAlfrm1_Load(object sender, EventArgs e)
        {
            sepetlistele();
            kitapsayisi();
        }

        private void txtIdAra_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("SELECT ad, soyad FROM uye WHERE id = @id", baglanti);
            komut.Parameters.AddWithValue("@id", txtIdAra.Text);

            SqlDataReader read = komut.ExecuteReader();
            if (read.Read())
            {
                txtAd.Text = read["ad"].ToString();
                txtSoyad.Text = read["soyad"].ToString();
            }
            baglanti.Close();

            baglanti.Open();
            SqlCommand komut2 = new SqlCommand("SELECT SUM(kitapsayisi) FROM emanetkitaplar", baglanti);
            lblKayitliKitapSayi.Text = komut2.ExecuteScalar()?.ToString() ?? "0";
            baglanti.Close();

            if (string.IsNullOrEmpty(txtIdAra.Text))
            {
                foreach (Control item in grpUyeBilgi.Controls)
                {
                    if (item is TextBox)
                    {
                        item.Text = "";
                        lblKayitliKitapSayi.Text = "";
                    }
                }
            }
        }

        private void txtIsbn_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIsbn.Text))
            {
                foreach (Control item in grpKitapBilgi.Controls)
                {
                    if (item is TextBox)
                    {
                        item.Text = "";
                    }
                }
                return;
            }

            baglanti.Open();
            SqlCommand komut = new SqlCommand("SELECT kitapadi, yazari FROM kitap WHERE isbn LIKE @isbn", baglanti);
            komut.Parameters.AddWithValue("@isbn", txtIsbn.Text + "%");

            SqlDataReader read = komut.ExecuteReader();
            if (read.Read())
            {
                txtKitapAdi.Text = read["kitapadi"].ToString();
                txtYazari.Text = read["yazari"].ToString();
            }
            baglanti.Close();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("DELETE FROM sepet WHERE isbn = @isbn", baglanti);
                komut.Parameters.AddWithValue("@isbn", dataGridView1.CurrentRow.Cells["isbn"].Value.ToString());
                komut.ExecuteNonQuery();
                baglanti.Close();

                MessageBox.Show("Silme işlemi yapıldı.");
                daset.Tables["sepet"].Clear();
                sepetlistele();
                lblKitapSayisi.Text = "";
                kitapsayisi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
        }

        private void btnOduncAl_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblKitapSayisi.Text))
            {
                if (!string.IsNullOrEmpty(txtIdAra.Text) && !string.IsNullOrEmpty(txtAd.Text) && !string.IsNullOrEmpty(txtSoyad.Text))
                {
                    try
                    {
                        int rowIndex = dataGridView1.CurrentCell.RowIndex;
                        baglanti.Open();
                        SqlCommand komut = new SqlCommand(
                            "INSERT INTO emanetkitaplar (id, ad, soyad, isbn, kitapadi, yazari, kitapsayisi, teslimtarihi, iadetarihi) " +
                            "VALUES (@id, @ad, @soyad, @isbn, @kitapadi, @yazari, @kitapsayisi, @teslimtarihi, @iadetarihi)",
                            baglanti);

                        komut.Parameters.AddWithValue("@id", txtIdAra.Text);
                        komut.Parameters.AddWithValue("@ad", txtAd.Text);
                        komut.Parameters.AddWithValue("@soyad", txtSoyad.Text);
                        komut.Parameters.AddWithValue("@isbn", dataGridView1.Rows[rowIndex].Cells["isbn"].Value.ToString());
                        komut.Parameters.AddWithValue("@kitapadi", dataGridView1.Rows[rowIndex].Cells["kitapadi"].Value.ToString());
                        komut.Parameters.AddWithValue("@yazari", dataGridView1.Rows[rowIndex].Cells["yazari"].Value.ToString());
                        komut.Parameters.AddWithValue("@kitapsayisi", int.Parse(dataGridView1.Rows[rowIndex].Cells["kitapsayisi"].Value.ToString()));
                        komut.Parameters.AddWithValue("@teslimtarihi", dataGridView1.Rows[rowIndex].Cells["teslimtarihi"].Value.ToString());
                        komut.Parameters.AddWithValue("@iadetarihi", dataGridView1.Rows[rowIndex].Cells["iadetarihi"].Value.ToString());
                        komut.ExecuteNonQuery();
                      
                        baglanti.Close();

                        baglanti.Open();
                        SqlCommand komut2 = new SqlCommand("DELETE FROM sepet WHERE isbn = @isbn", baglanti);
                        komut2.Parameters.AddWithValue("@isbn", dataGridView1.Rows[rowIndex].Cells["isbn"].Value.ToString());
                        komut2.ExecuteNonQuery();
                        baglanti.Close();

                        MessageBox.Show("Seçili kitap ödünç alındı.");
                        daset.Tables["sepet"].Clear();
                        sepetlistele();
                        lblKitapSayisi.Text = "";
                        kitapsayisi();
                        lblKayitliKitapSayi.Text = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Bir hata oluştu: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Önce üye bilgilerini doldurmalısınız!");
                }
            }
            else
            {
                MessageBox.Show("Önce sepete kitap ekleyiniz.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
