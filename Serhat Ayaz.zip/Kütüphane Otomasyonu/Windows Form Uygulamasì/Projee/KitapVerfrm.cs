﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Projee
{
    public partial class KitapVerfrm : Form
    {
        public KitapVerfrm()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=BLACK\\SQLEXPRESS;Initial Catalog=KütüphaneYönetimSistemi;Integrated Security=True;Encrypt=False");
        DataSet daset = new DataSet();

        

        private void EmanetListele()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from EmanetKitaplar", baglanti);
            adtr.Fill(daset, "EmanetKitaplar");
            dataGridView1.DataSource = daset.Tables["EmanetKitaplar"];
            baglanti.Close();
        }

        

        private void KitapVerfrm_Load(object sender, EventArgs e)
        {
            EmanetListele();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            EmanetListele();
        }

        private void btnIadeEt_Click_1(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("delete from emanetkitaplar where isbn = @isbn and id = @id", baglanti);
            komut.Parameters.AddWithValue("@id", dataGridView1.CurrentRow.Cells["id"].Value.ToString());
            komut.Parameters.AddWithValue("@isbn", dataGridView1.CurrentRow.Cells["isbn"].Value.ToString());
            komut.ExecuteNonQuery();
            SqlCommand komut2 = new SqlCommand("UPDATE kitap SET stoksayisi = stoksayisi + '"+ dataGridView1.CurrentRow.Cells["isbn"].Value.ToString()+ "' WHERE isbn = @isbn", baglanti);
            komut2.Parameters.AddWithValue("@isbn", dataGridView1.CurrentRow.Cells["isbn"].Value.ToString());
            komut2.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Kitap başarıyla iade edildi.");
            daset.Tables["EmanetKitaplar"].Clear();
            EmanetListele();
            
        }

        private void btnIptal_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            daset.Tables["EmanetKitaplar"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from EmanetKitaplar where id like '%"+txtIdAra.Text+"%'",baglanti);
            adtr.Fill(daset,"EmanetKitaplar");
            baglanti.Close();
            if (txtIdAra.Text=="")
            {
                daset.Tables["EmanetKitaplar"].Clear();
                EmanetListele();
            }
        }

        private void txtIsbnAra_TextChanged(object sender, EventArgs e)
        {
            daset.Tables["EmanetKitaplar"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select *from EmanetKitaplar where isbn like '%" + txtIsbnAra.Text + "%'", baglanti);
            adtr.Fill(daset, "EmanetKitaplar");
            baglanti.Close();
            if (txtIsbnAra.Text == "")
            {
                daset.Tables["EmanetKitaplar"].Clear();
                EmanetListele();
            }
        }
    }
}
