﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Projee
{
    public partial class UyeEklefrm : Form
    {
        public UyeEklefrm()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=BLACK\\SQLEXPRESS;Initial Catalog=KütüphaneYönetimSistemi;Integrated Security=True;Encrypt=False");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnIptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUyeEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text) || string.IsNullOrEmpty(txtAdi.Text) || string.IsNullOrEmpty(txtSoyadi.Text) || string.IsNullOrEmpty(comboUyelikTipi.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun.");
                return;
            }
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("INSERT INTO uye(id,ad,soyad,uyelik) VALUES(@id,@ad,@soyad,@uyelik)", baglanti);
                komut.Parameters.AddWithValue("@id", txtId.Text);
                komut.Parameters.AddWithValue("@ad", txtAdi.Text);
                komut.Parameters.AddWithValue("@soyad", txtSoyadi.Text);
                komut.Parameters.AddWithValue("@uyelik", comboUyelikTipi.Text);
                komut.ExecuteNonQuery();
                MessageBox.Show("Üye Kaydı Yapıldı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }

        }

        private void UyeEklefrm_Load(object sender, EventArgs e)
        {

        }
    }
}
