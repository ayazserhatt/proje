﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projee
{
    public partial class KitapEklefrm : Form
    {
        public KitapEklefrm()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=BLACK\\SQLEXPRESS;Initial Catalog=KütüphaneYönetimSistemi;Integrated Security=True;Encrypt=False");
        private void KitapEklefrm_Load(object sender, EventArgs e)
        {

        }

        private void btnİptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtIsbn.Text) || string.IsNullOrEmpty(txtKitapAdi.Text) || string.IsNullOrEmpty(txtYazari.Text) || string.IsNullOrEmpty(comboTuru.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun.");
                return;
            }
            try
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("INSERT INTO kitap(isbn,kitapadi,yazari,turu,stoksayisi,kayittarihi) VALUES(@isbn,@kitapadi,@yazari,@turu,@stoksayisi,@kayittarihi)", baglanti);
                komut.Parameters.AddWithValue("@isbn", txtIsbn.Text);
                komut.Parameters.AddWithValue("@kitapadi", txtKitapAdi.Text);
                komut.Parameters.AddWithValue("@yazari", txtYazari.Text);
                komut.Parameters.AddWithValue("@turu", comboTuru.Text);
                komut.Parameters.AddWithValue("@stoksayisi", txtStokSayisi.Text);

                komut.Parameters.AddWithValue("@kayittarihi", DateTime.Now.ToShortDateString());

                komut.ExecuteNonQuery();
                MessageBox.Show("Kitap Kaydı Yapıldı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }
        }
    }
}
