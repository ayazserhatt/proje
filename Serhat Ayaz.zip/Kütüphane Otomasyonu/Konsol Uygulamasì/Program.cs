﻿using System;
using System.Collections.Generic;
using System.IO;

namespace KutuphaneYonetim
{
    struct Kitap
    {
        public string ISBN;
        public string Ad;
        public string Yazar;
        public KitapTuru Tur;
        public bool Durum; 
    }

    struct Uye
    {
        public int UyeID;
        public string AdSoyad;
        public UyelikTipi UyelikTipi;
    }

    enum KitapTuru
    {
        Roman,
        Bilim,
        Sanat,
        Tarih,
        Felsefe
    }

    enum UyelikTipi
    {
        Standart,
        Premium
    }

    class Program
    {
        static List<Kitap> kitaplar = new List<Kitap>();
        static List<Uye> uyeler = new List<Uye>();

        static string Masaustu => Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        static string KitapDosyaYolu => Path.Combine(Masaustu, "kitaplar.txt");
        static string UyeDosyaYolu => Path.Combine(Masaustu, "uyeler.txt");

        static void Main(string[] args)
        {
            VerileriDosyadanOku();
            bool devam = true;

            while (devam)
            {
                Console.Clear();
                BaslikYaz("Kütüphane Yönetim Sistemine Hoşgeldiniz", ConsoleColor.Yellow, ConsoleColor.DarkBlue);

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("1- Kitap Ekle");
                Console.WriteLine("2- Üye Ekle");
                Console.WriteLine("3- Kitap Listele");
                Console.WriteLine("4- Üye Listele");
                Console.WriteLine("5- Kitap Ödünç Al");
                Console.WriteLine("6- Kitap İade Et");
                Console.WriteLine("7- Verileri Kaydet");
                Console.WriteLine("8- Verileri Dosyadan Oku");
                Console.WriteLine("9- Çıkış");
                Console.ResetColor();

                Console.Write("Seçiminizi yapınız: ");
                char secim = Console.ReadKey().KeyChar;
                Console.Clear();

                switch (secim)
                {
                    case '1':
                        KitapEkle();
                        break;
                    case '2':
                        UyeEkle();
                        break;
                    case '3':
                        KitapListele();
                        break;
                    case '4':
                        UyeListele();
                        break;
                    case '5':
                        KitapOduncAl();
                        break;
                    case '6':
                        KitapIadeEt();
                        break;
                    case '7':
                        VerileriDosyayaYaz();
                        break;
                    case '8':
                        VerileriDosyadanOku();
                        break;
                    case '9':
                        devam = false;
                        break;
                    default:
                        MesajYaz("Geçersiz seçim!", ConsoleColor.Red);
                        break;
                }
            }
        }

        static void KitapEkle()
        {
            BaslikYaz("Kitap Ekleme Menüsü", ConsoleColor.Green, ConsoleColor.Black);

            Console.Write("Kitap ISBN: ");
            string isbn = Console.ReadLine();
            Console.Write("Kitap Adı: ");
            string ad = Console.ReadLine();
            Console.Write("Kitap Yazarı: ");
            string yazar = Console.ReadLine();
            Console.WriteLine("Kitap Türü (0: Roman, 1: Bilim, 2: Sanat, 3: Tarih, 4: Felsefe): ");
            KitapTuru tur = (KitapTuru)int.Parse(Console.ReadLine());

            Kitap yeniKitap = new Kitap
            {
                ISBN = isbn,
                Ad = ad,
                Yazar = yazar,
                Tur = tur,
                Durum = false
            };
            kitaplar.Add(yeniKitap);
            MesajYaz("Kitap başarıyla eklendi!", ConsoleColor.Green);
        }

        static void UyeEkle()
        {
            BaslikYaz("Üye Ekleme Menüsü", ConsoleColor.Green, ConsoleColor.Black);

            Console.Write("Üye ID: ");
            int id = int.Parse(Console.ReadLine());
            Console.Write("Üye Ad Soyad: ");
            string adSoyad = Console.ReadLine();
            Console.WriteLine("Üyelik Tipi (0: Standart, 1: Premium): ");
            UyelikTipi uyelikTipi = (UyelikTipi)int.Parse(Console.ReadLine());

            Uye yeniUye = new Uye
            {
                UyeID = id,
                AdSoyad = adSoyad,
                UyelikTipi = uyelikTipi
            };
            uyeler.Add(yeniUye);
            MesajYaz("Üye başarıyla eklendi!", ConsoleColor.Green);
        }

        static void KitapListele()
        {
            BaslikYaz("Kitap Listesi", ConsoleColor.Blue, ConsoleColor.Black);
            foreach (var kitap in kitaplar)
            {
                Console.WriteLine($"ISBN: {kitap.ISBN}, Ad: {kitap.Ad}, Yazar: {kitap.Yazar}, Tür: {kitap.Tur}, Durum: {(kitap.Durum ? "Ödünç Alınmış" : "Mevcut")}");
            }
            Console.ReadLine();
        }

        static void UyeListele()
        {
            BaslikYaz("Üye Listesi", ConsoleColor.Blue, ConsoleColor.Black);
            foreach (var uye in uyeler)
            {
                Console.WriteLine($"ID: {uye.UyeID}, Ad Soyad: {uye.AdSoyad}, Üyelik Tipi: {uye.UyelikTipi}");
            }
            Console.ReadLine();
        }

        static void KitapOduncAl()
        {
            BaslikYaz("Kitap Ödünç Alma Menüsü", ConsoleColor.Magenta, ConsoleColor.Black);

            Console.Write("Ödünç alınacak kitabın ISBN'sini giriniz: ");
            string isbn = Console.ReadLine();
            for (int i = 0; i < kitaplar.Count; i++)
            {
                if (kitaplar[i].ISBN == isbn && !kitaplar[i].Durum)
                {
                    Kitap kitap = kitaplar[i];
                    kitap.Durum = true;
                    kitaplar[i] = kitap;
                    MesajYaz("Kitap başarıyla ödünç alındı!", ConsoleColor.Green);
                    return;
                }
            }
            MesajYaz("Kitap bulunamadı veya zaten ödünç alınmış.", ConsoleColor.Red);
        }

        static void KitapIadeEt()
        {
            BaslikYaz("Kitap İade Menüsü", ConsoleColor.Magenta, ConsoleColor.Black);

            Console.Write("İade edilecek kitabın ISBN'sini giriniz: ");
            string isbn = Console.ReadLine();
            for (int i = 0; i < kitaplar.Count; i++)
            {
                if (kitaplar[i].ISBN == isbn && kitaplar[i].Durum)
                {
                    Kitap kitap = kitaplar[i];
                    kitap.Durum = false;
                    kitaplar[i] = kitap;
                    MesajYaz("Kitap başarıyla iade edildi!", ConsoleColor.Green);
                    return;
                }
            }
            MesajYaz("Kitap bulunamadı veya zaten iade edilmiş.", ConsoleColor.Red);
        }

        static void VerileriDosyayaYaz()
        {
            using (StreamWriter sw = new StreamWriter(KitapDosyaYolu))
            {
                foreach (var kitap in kitaplar)
                {
                    sw.WriteLine($"{kitap.ISBN},{kitap.Ad},{kitap.Yazar},{kitap.Tur},{kitap.Durum}");
                }
            }
            using (StreamWriter sw = new StreamWriter(UyeDosyaYolu))
            {
                foreach (var uye in uyeler)
                {
                    sw.WriteLine($"{uye.UyeID},{uye.AdSoyad},{uye.UyelikTipi}");
                }
            }
            MesajYaz("Veriler masaüstüne kaydedildi.", ConsoleColor.Green);
        }

        static void VerileriDosyadanOku()
        {
            try
            {
                if (File.Exists(KitapDosyaYolu))
                {
                    using (StreamReader sr = new StreamReader(KitapDosyaYolu))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            var parts = line.Split(',');
                            if (parts.Length == 5) 
                            {
                                Kitap kitap = new Kitap
                                {
                                    ISBN = parts[0],
                                    Ad = parts[1],
                                    Yazar = parts[2],
                                    Tur = (KitapTuru)Enum.Parse(typeof(KitapTuru), parts[3]),
                                    Durum = bool.Parse(parts[4])
                                };
                                kitaplar.Add(kitap);
                            }
                        }
                    }
                }
                else
                {
                    MesajYaz("Kitap dosyası bulunamadı. Yeni bir dosya oluşturulacak.", ConsoleColor.Yellow);
                }

                if (File.Exists(UyeDosyaYolu))
                {
                    using (StreamReader sr = new StreamReader(UyeDosyaYolu))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            var parts = line.Split(',');
                            if (parts.Length == 3) 
                            {
                                Uye uye = new Uye
                                {
                                    UyeID = int.Parse(parts[0]),
                                    AdSoyad = parts[1],
                                    UyelikTipi = (UyelikTipi)Enum.Parse(typeof(UyelikTipi), parts[2])
                                };
                                uyeler.Add(uye);
                            }
                        }
                    }
                }
                else
                {
                    MesajYaz("Üye dosyası bulunamadı. Yeni bir dosya oluşturulacak.", ConsoleColor.Yellow);
                }
            }
            catch (Exception ex)
            {
                MesajYaz($"Dosya okuma sırasında bir hata oluştu: {ex.Message}", ConsoleColor.Red);
            }
        }


        static void BaslikYaz(string metin, ConsoleColor yaziRengi, ConsoleColor zeminRengi)
        {
            Console.BackgroundColor = zeminRengi;
            Console.ForegroundColor = yaziRengi;
            Console.WriteLine(new string('=', metin.Length));
            Console.WriteLine(metin);
            Console.WriteLine(new string('=', metin.Length));
            Console.ResetColor();
        }

        static void MesajYaz(string mesaj, ConsoleColor yaziRengi)
        {
            Console.ForegroundColor = yaziRengi;
            Console.WriteLine(mesaj);
            Console.ResetColor();
            Console.ReadLine();
        }
    }
}
